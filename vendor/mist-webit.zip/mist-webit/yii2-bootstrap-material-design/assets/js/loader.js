$(document).ready(function() {
    $.material.init();
});
